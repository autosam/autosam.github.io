/*  
  <action jsname="action_smPlayFootstepSound" description="SM Play Footstep Sound">
    <property name="Path" type="string" default="sounds/"/>
    <property name="FileName" type="string" default="*.ogg"/>
    <property name="StartNumber" type="int" default="1"/>
    <property name="EndNumber" type="int" default="4"/>
  </action>
*/

action_smPlayFootstepSound = function(){
  this.randomFn = function(min, max){
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
}

action_smPlayFootstepSound.prototype.execute = function (node){
  const number = this.randomFn(this.StartNumber, this.EndNumber);
  ccbPlaySound(this.Path + this.FileName.replace('*', number));
}