/*  
  <behavior jsname="behavior_SMFirstpersonCameraController" description="SM Firstperson Controller">
    <property name="Player" type="scenenode"/>
    <property name="PlayerCrouched" type="scenenode"/>
    <property name="CameraPositionOffset" type="vect3d" default="0, 8, 0"/>
    <property name="WalkSpeed" type="float" default="0.2"/>
    <property name="RunSpeed" type="float" default="0.35"/>
    <property name="CrouchSpeed" type="float" default="0.11"/>
    <property name="CrouchHeight" type="float" default="8"/>
    <property name="LeaningOffset" type="float" default="5"/>
    <property name="StandingShakeSpeed" type="float" default="0.001"/>
    <property name="StandingShakeStrength" type="float" default="0.2"/>
    <property name="WalkingShakeSpeed" type="float" default="0.0065"/>
    <property name="WalkingShakeStrength" type="float" default="0.4"/>
    <property name="RunShakeSpeed" type="float" default="0.01"/>
    <property name="RunShakeStrength" type="float" default="0.55"/>
    <property name="CrouchShakeSpeed" type="float" default="0.005"/>
    <property name="CrouchShakeStrength" type="float" default="0.8"/>
    <property name="CameraRollStrength" type="float" default="1"/>
    <property name="SidestepLeanStrength" type="float" default="0.075"/>
    <property name="SidestepLeanSpeed" type="float" default="0.008"/>
    <property name="CameraSmoothness" type="bool" default="true"/>
    <property name="CameraSmoothnessFactor" type="float" default="0.2"/>
    <property name="CameraRollStrength" type="float" default="1"/>
    <property name="StepImpactStrength" type="float" default="0.255"/>
    <property name="JumpStrength" type="float" default="0.25"/>
    <property name="JumpGravity" type="float" default="0.0025"/>
    <property name="KeyMoveForward" type="string" default="W"/>
    <property name="KeyMoveBackward" type="string" default="S"/>
    <property name="KeyMoveRight" type="string" default="D"/>
    <property name="KeyMoveLeft" type="string" default="A"/>
    <property name="KeyRun" type="string" default="Shift"/>
    <property name="KeyJump" type="string" default="Space"/>
    <property name="KeyCrouch" type="string" default="C"/>
    <property name="KeyLeanRight" type="string" default="E"/>
    <property name="KeyLeanLeft" type="string" default="Q"/>
    <property name="KeyLeanToggle" type="bool" default="false"/>
    <property name="ActionOnFootstep" type="action"/>
  </behavior>
*/

/* 
	(C) Smn Mhmdy, (https://autosam.github.io \\ autosam.sm@gmail.com \\ discord.gg/e6TpKsq)
	December 26, 2024 \\ version 1.0
*/

var smFPCAMERA;
behavior_SMFirstpersonCameraController = function(){
    smFPCAMERA = this;

    this.lastTime = 0;

    // this.CameraPositionOffset = new vector3d(0,2,3);
    this.CameraPositionOffset = new vector3d(0,5,0);
    this.CameraSmoothingSpeed = 0.007;
    this.WalkSpeed = 0.5;
    this.RunSpeed = 0.8;
    this.CrouchSpeed = 0.2;
    this.CrouchHeight = 10;
    this.LeaningOffset = 6;
    this.StandingShakeSpeed = 0.001;
    this.StandingShakeStrength = 0.5;
    this.WalkingShakeSpeed = 0.008;
    this.WalkingShakeStrength = 0.8;
    this.RunShakeSpeed = 0.01;
    this.RunShakeStrength = 1;
    this.CrouchShakeSpeed = 0.005;
    this.CrouchShakeStrength = 0.8;
    this.KeyMoveForward = 'W';
    this.KeyMoveBackward = 'S';
    this.KeyMoveRight = 'D';
    this.KeyMoveLeft = 'A';
    this.KeyRun = "Shift";

    // private extension variables
    this._privateLocalCameraPositionTarget = new vector3d(0,0,0);
    this._privateLocalCameraPositionCurrent = new vector3d(0,0,0);
    this.cameraShakeVector = new vector3d(0,0,0);
    this.PI2 = Math.PI;
    this.currentAnimationSpeed = 0;
    this.currentAnimationStr = 0;
    this.Matrot = new Matrixhelper();
    this.currentSidestepLean = 0;
    this.isCrouched = false;
    this.isLeaning = false;
    this.isDisabled = false;
    this.playerPosition = new vector3d(0,0,0);
    this.lastPlayerPosition = new vector3d(0,0,0);
    this.cameraSmoothPosition = new vector3d(0,0,0);
}

behavior_SMFirstpersonCameraController.prototype.onAnimate = function(node, Time){
    if(!this.node){
        this.node = node;

        this.PlayerNormalNode = this.Player;
        // this.PlayerCrouchedNode = ccbGetSceneNodeFromName("player_crouched");
        this.PlayerCrouchedNode = this.PlayerCrouched;
        this.Player = this.PlayerNormalNode;

        // init
        this.playerPosition = ccbGetSceneNodeProperty(this.Player, "Position");
        this.cameraSmoothPosition = this.playerPosition.copy();
        ccbSetSceneNodeProperty(this.node, "Position", this.playerPosition.add(this.CameraPositionOffset));
    }

    // time
    this.Time = new Date().getTime();
    this.deltaTime = this.Time - this.lastTime;
    this.lastTime = this.Time;
    if(this.deltaTime > 500) this.deltaTime = 10;

    if(this.isDisabled) return;

    // updates
    this.cameraPosition = ccbGetSceneNodeProperty(this.node, "Position");
    this.cameraTarget = ccbGetSceneNodeProperty(this.node, "Target");
    this.cameraRotation = ccbGetSceneNodeProperty(this.node, "Rotation");
    this.Matrot.setRotationDegrees(new vector3d(0, this.cameraRotation.y, this.cameraRotation.z));

    // key handler
    this.keyHandler();

    // player update
    this.playerHandler();

    // // camera update
    this.cameraHandler();
}

behavior_SMFirstpersonCameraController.prototype.playerHandler = function(){
    ccbSetSceneNodeProperty(this.Player, "Rotation", 0, this.cameraRotation.y, 0);
    this.lastPlayerPosition = this.playerPosition.copy();
    this.playerPosition = ccbGetSceneNodeProperty(this.Player, "Position");
    this.playerVelocity = this.lastPlayerPosition.substract(this.playerPosition);

    if(this.isCrouched)
        var speed = this.CrouchSpeed;
    else if(!Key.char[this.KeyRun])
        var speed = this.WalkSpeed;
    else
        var speed = this.RunSpeed

    var directionVector = new vector3d(0,0,0);

    if(Key.char[this.KeyMoveForward]){
        directionVector = directionVector.add(new vector3d(0,0,1));
    }
    if(Key.char[this.KeyMoveBackward]){
        directionVector = directionVector.add(new vector3d(0,0,-1));
    }
    if(Key.char[this.KeyMoveRight]){
        directionVector = directionVector.add(new vector3d(1,0,0));
    }
    if(Key.char[this.KeyMoveLeft]){
        directionVector = directionVector.add(new vector3d(-1,0,0));
    }

    if(this.isJumping){
        this.currentJumpVelocity -= this.JumpGravity * this.deltaTime;
        if(this.currentJumpVelocity <= 0) this.isJumping = false;
    }

    directionVector.normalize();
    directionVector.x *= speed * this.deltaTime * 0.1;
    directionVector.y *= speed * this.deltaTime * 0.1;
    directionVector.z *= speed * this.deltaTime * 0.1;

    if(this.isJumping){
        directionVector.y += this.currentJumpVelocity * this.deltaTime;
    }

    this.directionVectorLength = directionVector.getLength();
    this.Matrot.rotateVect(directionVector);

    this.playerPosition = this.playerPosition.add(directionVector);
    ccbSetSceneNodeProperty(this.Player, "Position", this.playerPosition);
}

behavior_SMFirstpersonCameraController.prototype.cameraHandler = function(){
    const privateLocalCameraPositionTarget = this._privateLocalCameraPositionTarget.copy();
    const   leanOffsetStart = this.CameraPositionOffset.copy(),
            leanOffsetTarget = this.CameraPositionOffset.add(privateLocalCameraPositionTarget);
            leanOffsetTarget.x *= 1.05;
    this.Matrot.rotateVect(leanOffsetStart);
    this.Matrot.rotateVect(leanOffsetTarget);
    const leanOffsetRayHit = RaycastAbs(
        this.playerPosition.add(leanOffsetStart),
        this.playerPosition.add(leanOffsetTarget)
    );
    if(leanOffsetRayHit){
        const hitOverrideOffset = this.playerPosition.add(leanOffsetTarget).substract(leanOffsetRayHit);
        this.Matrot.rotateVect(hitOverrideOffset);
        // ccbSetSceneNodeProperty(ccbGetSceneNodeFromName('debug'), 'Position', this.playerPosition.add(this.CameraPositionOffset).add(hitOverrideOffset))
        privateLocalCameraPositionTarget.x = hitOverrideOffset.x;
        
        const privateLocalCameraPositionCurrent = this._privateLocalCameraPositionCurrent.copy();
        this.Matrot.rotateVect(privateLocalCameraPositionCurrent);
        const targetIsPositive = privateLocalCameraPositionCurrent.x >= 0;
        if(
            (targetIsPositive && privateLocalCameraPositionTarget.x < 0) ||
            (!targetIsPositive && privateLocalCameraPositionTarget.x >= 0)
        ) privateLocalCameraPositionTarget.x = 0;
    }
    // ccbSetSceneNodeProperty(ccbGetSceneNodeFromName('debug'), 'Position', leanOffsetRayHit)

    this._privateLocalCameraPositionCurrent = LerpVector(
        this._privateLocalCameraPositionCurrent, 
        privateLocalCameraPositionTarget, 
        this.CameraSmoothingSpeed * this.deltaTime
    );

    this.cameraShakeHandler();
    this.cameraUpVectorHandler();

    var localPosition = this._privateLocalCameraPositionCurrent.add(this.CameraPositionOffset).add(this.cameraShakeVector);
    this.Matrot.rotateVect(localPosition);
    
    this.cameraSmoothPosition = this.CameraSmoothness ?
        LerpVector(this.cameraSmoothPosition, this.playerPosition, this.CameraSmoothnessFactor * 0.1 * this.deltaTime) :
        this.playerPosition.copy();
    ccbSetSceneNodeProperty(this.node, "Position", 
        this.cameraSmoothPosition.add(localPosition)
    );
}

behavior_SMFirstpersonCameraController.prototype.cameraShakeHandler = function(){
    if(this.directionalKeysPressed && this.directionVectorLength){
        if(this.isCrouched){
            var animationSpeed = this.CrouchShakeSpeed;
            var animationStr = this.CrouchShakeStrength;
        }
        else if(Key.char[this.KeyRun]){
            var animationSpeed = this.RunShakeSpeed;
            var animationStr = this.RunShakeStrength;
        } else {
            var animationSpeed = this.WalkingShakeSpeed;
            var animationStr = this.WalkingShakeStrength;            
        }
    } else {
            var animationSpeed = this.StandingShakeSpeed;
            var animationStr = this.StandingShakeStrength;        
    }

    this.currentAnimationSpeed = Lerp(this.currentAnimationSpeed, animationSpeed + (!this.directionalKeysPressed ? Global_MouseAxisX * 0.0001 : 0), 0.01 * this.deltaTime);
    this.currentAnimationStr = Lerp(this.currentAnimationStr, animationStr, 0.01 * this.deltaTime);
    if(this.SidestepLeanStrength){ // leaning when moving right and left
        var targetSidestepLean = 0
        if(Key.char[this.KeyMoveRight] && this.directionVectorLength)
            targetSidestepLean = this.SidestepLeanStrength;
        if(Key.char[this.KeyMoveLeft] && this.directionVectorLength)
            targetSidestepLean = -this.SidestepLeanStrength;
        this.currentSidestepLean = Lerp(this.currentSidestepLean, targetSidestepLean, this.SidestepLeanSpeed * this.deltaTime);
    }

    if(!this.cameraShakeFloat || this.cameraShakeFloat >= Math.PI){
        this.cameraShakeFloat = -Math.PI;
    }
    this.cameraShakeFloat += this.currentAnimationSpeed * this.deltaTime;

    this.cameraShakeVector.x = (Math.sin(this.cameraShakeFloat) + Math.cos(this.cameraShakeFloat)) * this.currentAnimationStr; 
    var lastSign = this.cameraShakeVector.y * 2 > 0 ? 1 : -1;
    this.cameraShakeVector.y = Math.sin(this.cameraShakeFloat * 2) * this.currentAnimationStr;
    var currentSign = this.cameraShakeVector.y * 2 > 0 ? 1 : -1;
    if(lastSign != currentSign && currentSign == -1 && this.directionalKeysPressed) { // footstep
        ccbInvokeAction(this.ActionOnFootstep);
        if(typeof playFootstepSound === "function")
            playFootstepSound();

        if(this.StepImpactStrength){
            this.stepImpactTime = 120;
            this.stepImpactSign = !this.stepImpactSign;
        }
    }

    if(this.stepImpactTime > 0){
        this.currentSidestepLean += this.StepImpactStrength * (this.stepImpactSign ? 1 : -1) * 0.001 * this.deltaTime;
        this.stepImpactTime -= this.deltaTime;
    }
}

behavior_SMFirstpersonCameraController.prototype.cameraUpVectorHandler = function(){
    var shakeFloat = (Math.sin(this.cameraShakeFloat) + Math.cos(this.cameraShakeFloat)) * this.currentAnimationStr * 0.02 * this.CameraRollStrength;
    var leaningFloat = this._privateLocalCameraPositionCurrent.x * 0.05;
    var upVector = new vector3d(shakeFloat + leaningFloat, 1, 0);
    upVector.x += this.currentSidestepLean;
    this.Matrot.rotateVect(upVector);
    upVector.y = 1;
    ccbSetSceneNodeProperty(this.node, "UpVector", upVector);
}

behavior_SMFirstpersonCameraController.prototype.keyHandler = function(){
    const me = this;
    // movement
    if(Key.char[this.KeyMoveForward] || Key.char[this.KeyMoveBackward] || Key.char[this.KeyMoveRight] || Key.char[this.KeyMoveLeft])
        this.directionalKeysPressed = true;
    else this.directionalKeysPressed = false;

    // crouching
    if(Key.char[this.KeyCrouch]){
        Key.char[this.KeyCrouch] = 0;
        // this._privateLocalCameraPositionTarget = this._privateLocalCameraPositionTarget.add(new vector3d(0, this.isCrouched ? 15 : -15, 0));
        if(this.isCrouched){
            if(!this.canUncrouch()) return false;
        }
        this.isCrouched = !this.isCrouched;
        this._privateLocalCameraPositionTarget.y = this.isCrouched ? -this.CrouchHeight : 0;
        var currentPlayerPosition = ccbGetSceneNodeProperty(this.Player, "Position");
        ccbSetSceneNodeProperty(this.Player, "Visible", false);
        this.Player = this.isCrouched ? this.PlayerCrouchedNode : this.PlayerNormalNode;
        ccbSetSceneNodePositionWithoutCollision(this.Player, currentPlayerPosition.x, currentPlayerPosition.y, currentPlayerPosition.z);
        ccbSetSceneNodeProperty(this.Player, "Visible", true);
    }

    // leaning
    const updatePrivateLocalCameraLeanPosition = function(){
        if(!me.isLeaning)
            me._privateLocalCameraPositionTarget.x = 0;
        else {
            me._privateLocalCameraPositionTarget.x = me.isLeaning == 1 ? me.LeaningOffset : -me.LeaningOffset;
        }
    }
    if(Key.char[this.KeyLeanRight] || Key.char[this.KeyLeanLeft]){
        
        if(Key.char[this.KeyLeanRight]){
            if(this.KeyLeanToggle) {
                Key.char[this.KeyLeanRight] = 0;
                this.isLeaning = this.isLeaning == 1 ? 0 : 1; 
            } else {
                this.isLeaning = 1;
            }
        } else {
            if(this.KeyLeanToggle) {
                Key.char[this.KeyLeanLeft] = 0;
                this.isLeaning = this.isLeaning == 2 ? 0 : 2;
            } else {
                this.isLeaning = 2;
            }
        }

        // this._privateLocalCameraPositionTarget = this._privateLocalCameraPositionTarget.add(new vector3d(, 0, 0));
        updatePrivateLocalCameraLeanPosition();
    } else {
        if(!this.KeyLeanToggle && this.isLeaning){
            this.isLeaning = 0;
            updatePrivateLocalCameraLeanPosition();
        }
    }

    // jumping
    if(Key.char['Space'] && !this.isJumping && Math.abs(this.playerVelocity.y) < 0.1){
        this.isJumping = true;
        this.currentJumpVelocity = this.JumpStrength;
    }
}

behavior_SMFirstpersonCameraController.prototype.canUncrouch = function(){
    var currentPlayerPosition = ccbGetSceneNodeProperty(this.Player, "Position");
    var pAdd = new vector3d(0, this.CameraPositionOffset.y + (this.CrouchHeight / 1.5), 0);
    for(var x = -1; x <= 1; x++)
        for(var z = -1; z <= 1; z++){
            var p = new vector3d(
                currentPlayerPosition.x + x * 1,
                this._privateLocalCameraPositionTarget.y + this.playerPosition.y + 1,
                currentPlayerPosition.z + z * 1
            );
            var hit = RaycastAbs(p, p.add(pAdd));
            if(hit) return false;
        }
    
    return true;
}

behavior_SMFirstpersonCameraController.prototype.setPosition = function(pos, noCollision){
    if(noCollision){
        ccbSetSceneNodePositionWithoutCollision(this.Player, pos.x, pos.y, pos.z);
        ccbSetSceneNodePositionWithoutCollision(this.PlayerCrouched, pos.x, pos.y, pos.z);
        return; 
    }

    ccbSetSceneNodeProperty(this.Player, "Position", pos);
    ccbSetSceneNodeProperty(this.PlayerCrouched, "Position", pos);
}

// Keys
Key = {
    char: {},
    code: {}
};
ccbRegisterKeyDownEvent("fKeyDown");
ccbRegisterKeyUpEvent("fKeyUp");
function fKeyDown (code) {
    if(Key.code[code] !== 0) Key.code[code] = true;
    if(Key.char[String.fromCharCode(code)] !== 0) Key.char[String.fromCharCode(code)] = true;

    // special codes
    switch(code){
        case 32:
            Key.char["Space"] = true;
            break;
        case 160:
            Key.char["Shift"] = true;
            break;
        case 162:
            Key.char["Ctrl"] = true;
            break;
        case 164:
            Key.char["Alt"] = true;
            break;
    }

    // if(ExternalKeyPress){
    //     ExternalKeyPress(code, true);
    // }
}
function fKeyUp (code) {
    Key.code[code] = false;
    Key.char[String.fromCharCode(code)] = false;

    // special codes
    switch(code){
        case 32:
            Key.char["Space"] = false;
            break;
        case 160:
            Key.char["Shift"] = false;
            break;
        case 162:
            Key.char["Ctrl"] = false;
            break;
        case 164:
            Key.char["Alt"] = false;
            break;
    }

    // if(ExternalKeyPress){
    //     ExternalKeyPress(code, false);
    // }
}

// behavior_SMFirstpersonCameraController.prototype.onMouseEvent = function(event, mwheeldata){

// }

Lerp = function(s, e, p){
    return (1 - p) * s + p * e;
}
LerpVector = function(s, e, t){
    return new vector3d(
        (1 - t) * s.x + t * e.x,
        (1 - t) * s.y + t * e.y,
        (1 - t) * s.z + t * e.z
        );
}
Clamp = function(n, min, max) {
    if (n < min) n = min;
    if (n > max) n = max;
    return n;
}
vector3d.prototype.copy = function(){
    return new vector3d(this.x, this.y, this.z);
}
Random = function(min, max){
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
}
RaycastAbs = function(rayStart, rayTarget){
    this.rayCollider = ccbGetCollisionPointOfWorldWithLine(rayStart.x,rayStart.y,rayStart.z,rayTarget.x,rayTarget.y,rayTarget.z);
    if(this.rayCollider)
        return this.rayCollider;
    else
        return false;   
}