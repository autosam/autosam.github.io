/*  
  <behavior jsname="behavior_smMouseLook" description="SM Mouse Look">
    <property name="Sensitivity" type="float" default="100"/>
    <property name="SensitivityH" type="float" default="100"/>
    <property name="SensitivityV" type="float" default="100"/>
    <property name="AngleClamp" type="float" default="88"/>
    <property name="FPSIndependence" type="bool" default="false"/>
    <property name="ChangeSensUsingMouseWheel" type="bool" default="false"/>

  </behavior>
*/

var MouseLook; // global mouse look object
var Setting_Sens; // both horizontal and vertical sensitivity
var Setting_SensH; // horizontal sensitivity
var Setting_SensV; // vertical sensitivity
var Setting_MouseFpsIndependence; // frame time affects sensitivity if true
var Setting_ChangeSensUsingMouseWheel; // allows the sensitivity to be changed using mouse wheel if true
var Setting_AngleClamp; // clamps the vertical angle
var Global_MouseAxisX = 0; // reference to mouse's x axis input value
var Global_MouseAxisY = 0; // reference to mouse's y axis input value
var _DisableMouseLook; // disables the mouse look if true
var Setting_MouseHandler; // different mouse handling calculations
var Global_MouseWheelData = 0;

// Constructor
behavior_smMouseLook = function(node){
    MouseLook = this;
    this.lastTime = 0;
    this.currentRotation = new vector3d(0,0,0);
    this.Matrot = new Matrixhelper();

    if(!Setting_Sens) Setting_Sens = 20;
    if(!Setting_SensH) Setting_SensH = Setting_Sens;
    if(!Setting_SensV) Setting_SensV = Setting_Sens;
    if(!Setting_MouseHandler) Setting_MouseHandler = 1;
    ccbSetCursorVisible(false);
}

// Runs this code on every frame
behavior_smMouseLook.prototype.onAnimate = function (node, Time){
    if(!this.node){
        this.node = node;

        if(this.Sensitivity != -1){
            if(this.Sensitivity){
                Setting_Sens = this.Sensitivity;
                Setting_SensV = this.Sensitivity;
                Setting_SensH = this.Sensitivity;
            }
            Setting_SensV = this.SensitivityV;
            Setting_SensH = this.SensitivityH;
        }
        
        Setting_MouseFpsIndependence = this.FPSIndependence;
        Setting_ChangeSensUsingMouseWheel = this.ChangeSensUsingMouseWheel;
        Setting_AngleClamp = this.AngleClamp;

        this.currentRotation = ccbGetSceneNodeProperty(this.node, "Rotation");
    }

    // time
    this.Time = new Date().getTime();
    this.deltaTime = this.Time - this.lastTime;
    this.lastTime = this.Time;
    if(this.deltaTime > 1000) this.deltaTime = 1000;

    this.screenW = ccbGetScreenWidth();
    this.screenH = ccbGetScreenHeight();

    this.mouseY = ccbGetMousePosY();
    this.mouseX = ccbGetMousePosX();

    ccbSetMousePos(this.screenW / 2, this.screenH / 2);

    this.xAxisRaw = (this.mouseX - this.screenW/2);
    this.yAxisRaw = (this.mouseY - this.screenH/2);

    this.currentPosition = ccbGetSceneNodeProperty(this.node, "PositionAbs");
    
    if(Math.abs(this.xAxisRaw) < 1) this.xAxisRaw = 0;
    if(Math.abs(this.yAxisRaw) < 1) this.yAxisRaw = 0;

    Global_MouseAxisX = this.xAxisRaw, Global_MouseAxisY = this.yAxisRaw;

    if(_DisableMouseLook) {
        this.xAxisRaw = 0;
        this.yAxisRaw = 0;
        // return false;
    }

    // normalizing the y rotation between 0 and 360
    while(this.currentRotation.y >= 360){
        this.currentRotation.y -= 360;
    }
    while(this.currentRotation.y < 0){
        this.currentRotation.y += 360;
    }

    var xAxis = this.xAxisRaw * Setting_SensH * 0.001 * ((Setting_MouseFpsIndependence) ? this.deltaTime * 0.1 : 1);
    var yAxis = this.yAxisRaw * Setting_SensV * 0.001 * ((Setting_MouseFpsIndependence) ? this.deltaTime * 0.1 : 1);

    this.currentRotation.y += xAxis;
    this.currentRotation.x += yAxis;

    var clp = this.Clamp(this.currentRotation.x, -Setting_AngleClamp, Setting_AngleClamp);
    this.currentRotation.x = clp.num;

    if(clp.state)
        Global_MouseAxisY = 0;

    this.Matrot.setRotationDegrees(this.currentRotation.copy());
    this.forwardVector = new vector3d(0, 0, 1);
    this.Matrot.rotateVect(this.forwardVector);

    ccbSetSceneNodeProperty(this.node, "Target", this.currentPosition.add(this.forwardVector));
    ccbSetSceneNodeProperty(this.node, "Rotation", this.currentRotation);
}

behavior_smMouseLook.prototype.setRotation = function(rotation){
    this.currentRotation = rotation;

    this.Matrot.setRotationDegrees(this.currentRotation.copy());
    var forwardVector = new vector3d(0, 0, 1);
    this.Matrot.rotateVect(forwardVector);

    ccbSetSceneNodeProperty(this.node, "Target", this.currentPosition.add(forwardVector));  
}

behavior_smMouseLook.prototype.onMouseEvent = function(event, wdata){
    Global_MouseWheelData += wdata;
    if(!Setting_ChangeSensUsingMouseWheel) return;
    Setting_SensH += wdata;
    Setting_SensV += wdata;
}

// Clamps a number between two given values
behavior_smMouseLook.prototype.Clamp = function(n, min, max) {
    var s = false;
    if (n < min) n = min, s = true;
    if (n > max) n = max, s = true;
    return {num: n, state: s};
}

// Matrix transformation handler
// Originally by N.Gebhardt \\ office@ambiera.com
Matrixhelper = function(bMakeIdentity)
{
    if (bMakeIdentity == null)
        bMakeIdentity = true;
        
    this.m00 = 0;
    this.m01 = 0;
    this.m02 = 0;
    this.m03 = 0;
    this.m04 = 0;
    this.m05 = 0;
    this.m06 = 0;
    this.m07 = 0;
    this.m08 = 0;
    this.m09 = 0;
    this.m10 = 0;
    this.m11 = 0;
    this.m12 = 0;
    this.m13 = 0;
    this.m14 = 0;
    this.m15 = 0;
    
    this.bIsIdentity=false;
    
    if (bMakeIdentity)
    {
        this.m00 = 1;
        this.m05 = 1;
        this.m10 = 1;
        this.m15 = 1;
        this.bIsIdentity = true;
    }
}
Matrixhelper.prototype.rotateVect = function(v)
{
    var tmp = new vector3d(v.x, v.y, v.z);
    v.x = tmp.x*this.m00 + tmp.y*this.m04 + tmp.z*this.m08;
    v.y = tmp.x*this.m01 + tmp.y*this.m05 + tmp.z*this.m09;
    v.z = tmp.x*this.m02 + tmp.y*this.m06 + tmp.z*this.m10;
}
Matrixhelper.prototype.setRotationDegrees = function(v)
{
    var c = 3.14159265359 / 180.0;
    v.x *= c;
    v.y *= c;
    v.z *= c;
    this.setRotationRadians(v);
}
Matrixhelper.prototype.setRotationRadians = function(rotation)
{
    var cr = Math.cos( rotation.x );
    var sr = Math.sin( rotation.x );
    var cp = Math.cos( rotation.y );
    var sp = Math.sin( rotation.y );
    var cy = Math.cos( rotation.z );
    var sy = Math.sin( rotation.z );

    this.m00 = ( cp*cy );
    this.m01 = ( cp*sy );
    this.m02 = ( -sp );

    var srsp = sr*sp;
    var crsp = cr*sp;

    this.m04 = ( srsp*cy-cr*sy );
    this.m05 = ( srsp*sy+cr*cy );
    this.m06 = ( sr*cp );

    this.m08 = ( crsp*cy+sr*sy );
    this.m09 = ( crsp*sy-sr*cy );
    this.m10 = ( cr*cp );
    
    this.bIsIdentity = false;
}

// Returns the vector as a new object
vector3d.prototype.copy = function(){
    return new vector3d(this.x, this.y, this.z);
}